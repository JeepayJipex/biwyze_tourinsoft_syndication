<?php

namespace BiwyzeTourinsoft\Config;

class Fields
{
    public static function getOptions() {
        return [
            'Photos' => 'gallery'
        ];
    }
}