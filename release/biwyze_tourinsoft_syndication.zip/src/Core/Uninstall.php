<?php

namespace BiwyzeTourinsoft\Core;
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}
class Uninstall {

}