export default {
  input: 'assets/js/main.js',
  output: {
    file: './assets/js/biwyze_tourinsoft_syndication.js',
    format: 'iife'
  }
};